<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Производственная система</title>
    <link href="/favicoSokol.png" rel="icon">
    <script type="module" src="/build/assets/app-7-dRl9UK.js"></script>
    <link rel="stylesheet" href="/build/assets/app-ydaDk274.css">
    <link rel="stylesheet" href="/build/assets/app-uAWNV_XY.css"> 
    <link rel="manifest" href="/build/manifest.json">  
    <!-- @vite(['resources/js/app.js', 'resources/css/app.css']) -->
</head>
<body>
    <div id="app"></div>
</body>
</html>
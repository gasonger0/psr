Для локального запуска в .env  добавить:
FILE_UID=1000
FILE_GID=1000

WWW_PORT_VITE=5173
WWW_PORT=8001
MYSQL_PORT=3306
PHPMYADMIN_PORT=8000


TODO
1) Почему-то в цикле перебирается getActiveSlots и не находятся слоты для некоторых продуктов ()